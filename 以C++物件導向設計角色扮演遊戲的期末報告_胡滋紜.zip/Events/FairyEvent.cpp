#include "FairyEventh.h"
#include "ShieldArmor.h"
#include "TunicArmor.h"
#include "LifePotion.h"
#include "NovicePlayer.h"
#include <iostream>
using namespace std;

FairyEvent::FairyEvent()
{
	shield = new ShieldArmor;
	tunic = new TunicArmor;
	life_potion = new LifePotion;
}

void FairyEvent::display(vector<NovicePlayer*> & player_list)
{
	cout << "\nThere's a trapped fairy crying..." << endl;
	cout << "\n" << player_list[0]->getName() << " helps the fairy and the fairy is free now!\n" << endl;
	system("pause");
	system("cls");
	cout << "\nFairy: Thank you for saving my life. I will give you some gifts in return." << endl;
	cout << "\nThe fairy gives " << player_list[0]->getName() << " a bottle of life potion." << endl;
	bool get;
	get = player_list[0]->putItem(life_potion);
	if (!get)
		cout << "\nExceed backpack solt limit (" << player_list[0]->get_backpack_slot_limit() <<
		") or backpack weight limit (" << player_list[0]->get_backpack_weight_limit() <<
		"). It's a pity " << player_list[0]->getName() <<" can't have the gift." << endl;
	int i = 0;
	if (player_list.size() > 1)	i++;
	cout << "\nThe fairy gives " << player_list[i]->getName() << " a shield." << endl;
	get = player_list[i]->equipArmor(shield);
	if (!get)
		cout << "\nExceed backpack solt limit (" << player_list[i]->get_backpack_slot_limit() <<
		") or backpack weight limit (" << player_list[i]->get_backpack_weight_limit() <<
		"). It's a pity " << player_list[i]->getName() << " can't have the gift." << endl;
	if (player_list.size() > 2)	i++;
	cout << "\nThe fairy gives " << player_list[i]->getName() << " a tunic." << endl;
	get = player_list[i]->equipArmor(tunic);
	if (!get)
		cout << "\nExceed backpack solt limit (" << player_list[i]->get_backpack_slot_limit() <<
		") or backpack weight limit (" << player_list[i]->get_backpack_weight_limit() <<
		"). It's a pity " << player_list[i]->getName() << " can't have the gift." << endl;
	cout << endl;
	system("pause");
	system("cls");
}

FairyEvent::~FairyEvent()
{
	delete shield;
	delete tunic;
	delete life_potion;
}
