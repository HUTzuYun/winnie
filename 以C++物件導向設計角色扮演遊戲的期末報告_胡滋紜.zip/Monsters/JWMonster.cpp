#include "JWMonster.h"
#include <sstream>
#include <iostream>
using namespace std;

BaseMonster* JWMonster::unserialize(string s)
{
	BaseMonster *BaseMonsterPtr = new JWMonster;
	stringstream ss(s);
	string temp;
	getline(ss, temp, '$');
	if (temp != "JWMonster")
		cout << "Warning: This string is not serialized as JWMonster." << endl;
	getline(ss, temp, '$');
	BaseMonsterPtr->setHP(stoi(temp));
	getline(ss, temp, '$');
	BaseMonsterPtr->setMP(stoi(temp));
	return BaseMonsterPtr;
}

JWMonster::JWMonster()
	:BaseMonster("JWMonster", 120, 100, 42, 175, 250, 100)
{
}

string JWMonster::serialize()
{
	stringstream ss;
	ss << name << "$" << getHP() << "$" << getMP() << "$";
	string s = ss.str();
	return s;
}

JWMonster::~JWMonster()
{
	--count;
}