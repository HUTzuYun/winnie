#include "NovicePlayer.h"
#include "LifePotion.h"
#include "MagicPotion.h"
#include <math.h>
#include <iostream>
#include <sstream>
using namespace std;

NovicePlayer* NovicePlayer::unserialize(string s)           //static function
{
	NovicePlayer *NovicePlayerPtr = new NovicePlayer;
	stringstream ss(s);
	string temp;
	getline(ss, temp, '$');
	if (temp != "NovicePlayer")
		cout << "Warning: This string is not serialized as NovicePlayer." << endl;
	getline(ss, temp, '$');
	NovicePlayerPtr->setName(temp);
	getline(ss, temp, '$');
	NovicePlayerPtr->setLevel(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setHp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setMp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setExp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setMoney(stoi(temp));
	return NovicePlayerPtr;
}

NovicePlayer::NovicePlayer()                               //Constructors
{
	setExp(0);
	setMoney(100);
	backpack_slot = backpack_weight = 0;
	weapon = NULL;
	armor = NULL;
	setLevel(1);
	setHp(max_hp);
	setMp(max_mp);
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
	setName("anonymous");
}

NovicePlayer::NovicePlayer(int L)
{
	setExp(0);
	setMoney(100);
	backpack_slot = backpack_weight = 0;
	weapon = NULL;
	armor = NULL;
	setLevel(L);
	setHp(max_hp);
	setMp(max_mp);
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
	setName("anonymous");
}

NovicePlayer::NovicePlayer(int L, string N)
{
	setExp(0);
	setMoney(100);
	backpack_slot = backpack_weight = 0;
	weapon = NULL;
	armor = NULL;
	setLevel(L);
	setHp(max_hp);
	setMp(max_mp);
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
	setName(N);
}

NovicePlayer::NovicePlayer(const NovicePlayer& NP)          //copy constructor
{
	if (NP.weapon == NULL)weapon = NULL;
	else weapon = NP.weapon;
	if (NP.armor == NULL)armor = NULL;
	else armor = NP.armor;
	setLevel(NP.level);
	backpack = new Item*[NP.backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NP.backpack[i];
	setName(NP.name);
	setHp(NP.hp);
	setMp(NP.mp);
	setExp(NP.exp);
	setMoney(NP.money);
	backpack_weight = NP.backpack_weight;
	backpack_slot = NP.backpack_slot;
}

void NovicePlayer::setLevel(int L)                          //Set & Get Functions
{
	level = L;
	max_hp = 100 + 10 * L;
	max_mp = 40 + 5 * L;
	if (weapon == NULL)
		attack = 20 + 5 * L;
	else
		attack = 20 + 5 * L + weapon->attack_increment;
	if (armor == NULL)
		defense = 20 + 5 * L;
	else
		defense = 20 + 5 * L + armor->defense_increment;
	lvup_exp = ceil(pow(10, log2(L + 1)));
	backpack_weight_limit = 100 + 50 * L;
	backpack_slot_limit = 1 + L;
}

int NovicePlayer::getLevel() const
{
	return level;
}

void NovicePlayer::setName(string N)
{
	name = N;
}

string NovicePlayer::getName() const
{
	return name;
}

void NovicePlayer::setHp(int H)
{
	if (H < 0) hp = 0;
	else if (H <= max_hp) hp = H;
	else
	{
		cout << "\nhp exceeds max_hp. Set hp(" << H << ") to max_hp (" << max_hp << ")." << endl;
		hp = max_hp;
	}
}

int NovicePlayer::getHp() const
{
	return hp;
}

void NovicePlayer::setMp(int M)
{
	if (M < 0) mp = 0;
	else if (M <= max_mp) mp = M;
	else
	{
		cout << "\nmp exceeds max_mp. Set mp(" << M << ") to max_mp (" << max_mp << ")." << endl;
		mp = max_mp;
	}
}

int NovicePlayer::getMp() const
{
	return mp;
}

void NovicePlayer::setExp(int E)
{
	if (E < 0) exp = 0;
	if (E <= lvup_exp) exp = E;
	else
	{
		setLevel(getLevel() + 1);
		exp = E;
	}
}

int NovicePlayer::getExp() const
{
	return exp;
}

void NovicePlayer::setMoney(int Money)
{
	if (Money < 0) Money = 0;
	else 
		money = Money;
}

int NovicePlayer::getMoney() const
{
	return money;
}

int NovicePlayer::getAttack() const
{
	return attack;
}

int NovicePlayer::getDefense() const
{
	return defense;
}

void NovicePlayer::specialSkill()
{
}

string NovicePlayer::serialize()
{
	stringstream ss;
	ss << "NovicePlayer" << "$";
	ss << getName() << "$";
	ss << getLevel() << "$";
	ss << getHp() << "$";
	ss << getMp() << "$";
	ss << getExp() << "$";
	ss << getMoney() << "$";
	ss << get_weapon() << "$";
	ss << get_armor() << "$";
	ss << get_backpack_slot() << "$";
	for (int i = 0; i < get_backpack_slot(); i++)
		ss << getItem(i)->name << "$";
	string s;
	s = ss.str();
	return s;
}

bool NovicePlayer::equipWeapon(WeaponItems* weaponPtr)
{
	if (weaponPtr->level_required > level)
		return false;
	else if (weapon == NULL)
	{
		weapon = weaponPtr;
		attack = getAttack() + weaponPtr->attack_increment;
		return true;
	}
	else if(putItem(dynamic_cast<Item*>(weapon)) == true)
	{
		attack = getAttack() + weaponPtr->attack_increment - weapon->attack_increment;
		weapon = weaponPtr;
		return true;
	}
	else
		return false;
}

bool NovicePlayer::equipArmor(ArmorItems* armorPtr)
{
	if (armorPtr->level_required > level)
		return false;
	else if (armor == NULL)
	{
		armor = armorPtr;
		defense = getDefense() + armorPtr->defense_increment;
		return true;
	}
	else if (putItem(dynamic_cast<Item*>(armor)) == true)
	{
		armor = armorPtr;
		defense = getDefense() + armorPtr->defense_increment;
		return true;
	}
	else
		return false;
}

bool NovicePlayer::useConsumable(string consumable)
{
	for (int i = 0; i < backpack_slot_limit; i++)
	{
		if (backpack[i] == NULL) 
		{
			return false;
			break;
		}
		else if (backpack[i]->name == consumable)
		{
			takeItem(i);
			if (consumable == "Life Juice")
				setHp(getHp() + 50);
			else if (consumable == "Magic Fruit")
				setMp(getMp() + 50);
			return true;
			break;
		}
	}
}

bool NovicePlayer::putItem(Item* itemPtr)
{
	if (backpack_slot == backpack_slot_limit)
		return false;
	else if (backpack_weight + itemPtr->weight > backpack_weight_limit)
		return false;
	else 
	{
		backpack[backpack_slot] = itemPtr;
		backpack_weight += itemPtr->weight;
		backpack_slot++;
		return true;
	}
}

Item* NovicePlayer::takeItem(int takeNum)
{
	Item* toReturn = backpack[takeNum];
	backpack_weight = backpack_weight - toReturn->weight;
	if (takeNum == backpack_slot - 1);
	else 
	{
		for (int i = takeNum; i < backpack_slot - 1; i++)
			backpack[i] = backpack[i + 1];
	}
	backpack[backpack_slot - 1] = NULL;
	--backpack_slot;
	return toReturn;
}

int NovicePlayer::get_backpack_weight_limit() const
{
	return backpack_weight_limit;
}

int NovicePlayer::get_backpack_slot_limit() const
{
	return backpack_slot_limit;
}

int NovicePlayer::get_backpack_weight() const
{
	return backpack_weight;
}

Item* NovicePlayer::getItem(int i) const
{
	if (backpack[i] != NULL)
		return backpack[i];
}

int NovicePlayer::get_backpack_slot() const
{
	return backpack_slot;
}

string NovicePlayer::get_weapon() const
{
	if (weapon == NULL)
		return "None";
	else
		return weapon->name;
}


string NovicePlayer::get_armor() const
{
	if (armor == NULL)
		return "None";
	else
		return armor->name;
}

NovicePlayer::~NovicePlayer()
{
	delete[] backpack;
}