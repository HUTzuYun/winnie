#ifndef KNIGHTPLAYER_H
#define KNIGHTPLAYER_H

#include"NovicePlayer.h"
#include <string>
using namespace std;

class KnightPlayer : public NovicePlayer
{
public: 
	KnightPlayer();
	KnightPlayer(int);
	KnightPlayer(int, string);
	KnightPlayer(const KnightPlayer&);
	virtual void setLevel(int);
	virtual void specialSkill();      //increasing HP (level*10) points by decreasing MP (level*5) points
	virtual string serialize();

	static NovicePlayer* unserialize(string);
};
#endif // !KNIGHTPLAYER_H

