#include "BattleMenu.h"
#include "Field.h"
#include <iostream>
using namespace std;

BattleMenu::BattleMenu(Battle& b, Field* f)
{
	battle = &b;
	fptr = f;
}

void BattleMenu::display() const
{
	cout << "\nEntering the battle......" << endl;
}

char BattleMenu::input()
{
	cout << "\nThere's a monster!" << endl;
	bool legal;
	char re;
	cout << "\nFight now: 1 | Flee: 2" << endl;
	do {
		string sIn;
		legal = true;
		cout << "\nPlease enter 1 to fight or 2 to flee:";
		getline(cin, sIn);
		cout << endl;
		if (sIn.size() != 1)
			legal = false;
		else if (sIn == "1" || sIn == "2")
			re = sIn[0];
		else
			legal = false;
	} while (legal == false);
	system("cls");
	return re;
}

BattleMenu::~BattleMenu()
{
}