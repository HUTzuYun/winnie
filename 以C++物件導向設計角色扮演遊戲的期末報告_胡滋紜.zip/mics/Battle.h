#ifndef BATTLE_H
#define BATTLE_H

#include "BaseMonster.h"
#include "JWMonster.h"
#include "ZombieMonster.h"
#include "GoblinMonster.h"
#include "NovicePlayer.h"

#include <vector>
using namespace std;

struct Character
{
	char type; 
	bool alive = 1;
	void *instance; 
};

class Battle
{
public:
	Battle(vector<NovicePlayer*>&, BaseMonster**, int, int, int);
	Battle(vector<NovicePlayer*>&, BaseMonster**, int, int);
	Battle(vector<NovicePlayer*>&, int);
	Battle(vector<NovicePlayer*>&, int, int);
	void action(vector<NovicePlayer*>&);
	void nextActor();
	int getTurnCount() const;
	int getTurnLimit() const;
	Character getCurrentActor();
	Character* getPlayers();
	Character* getMonsters();
	int getPlayerCount() const;
	int getPlayerCount(bool) const;
	int getMonsterCount() const;
	int getMonsterCount(bool) const;
	virtual ~Battle();
private:
	Character *actionList;
	BaseMonster** monsterList;
	GoblinMonster goblin;
	BaseMonster *ptrG;
	ZombieMonster zombie;
	BaseMonster *ptrZ;
	JWMonster jw;
	BaseMonster *ptrJW ;
	int turnNum;
	int turnLimit;
	int playerNum;
	int monsterNum;
	int attackNum;
};


#endif 