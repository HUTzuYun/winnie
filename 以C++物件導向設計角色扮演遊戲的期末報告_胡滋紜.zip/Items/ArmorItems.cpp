#include "ArmorItems.h"

ArmorItems::ArmorItems(
	const int levelRequired, const string &nameIn, const string &effect,
	const string &descriptionIn, const int weightIn, const char typeIn, const int costIn, const int defenseIncrement)
	: Item(levelRequired, nameIn, effect, descriptionIn, weightIn, typeIn, costIn), defense_increment(defenseIncrement)
{
}