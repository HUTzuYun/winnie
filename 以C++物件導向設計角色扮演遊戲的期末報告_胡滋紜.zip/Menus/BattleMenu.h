#ifndef BATTLEMENU_H
#define BATTLEMENU_H

#include "Menu.h"
#include "Battle.h"
class Field;

class BattleMenu : public Menu
{
public:
	BattleMenu(Battle&, Field*);
	virtual void display() const;
	virtual char input();
	virtual ~BattleMenu();
private:
	Battle* battle;
	Field* fptr;
};

#endif // !BATTLEMENU_H

