#ifndef GOBLINMONSTER_H
#define GOBLINMONSTER_H

#include "BaseMonster.h"

class GoblinMonster : public BaseMonster
{
public:
	GoblinMonster();
	virtual string serialize();
	~GoblinMonster();

	static BaseMonster* unserialize(string);
};

#endif
