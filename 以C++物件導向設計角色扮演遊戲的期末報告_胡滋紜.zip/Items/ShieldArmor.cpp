#include "ShieldArmor.h"

ShieldArmor::ShieldArmor()
	: ArmorItems(2, "Holy Shield", "defense + 50", "A silver-made shield. Use it to protect yourself.", 50, 'a', 100, 50)
{
}
