#ifndef MENU_H
#define MENU_H

class Menu
{
public:
	Menu();
	virtual void display() const = 0;
	virtual char input() = 0;
	virtual ~Menu() {}
};

#endif // !MENU_H

