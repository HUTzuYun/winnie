#ifndef SHOPEVENT_H
#define SHOPEVENT_H

#include "Event.h"
#include "AxeWeapon.h"
#include "SwordWeapon.h"
#include "ShieldArmor.h"
#include "TunicArmor.h"
#include "LifePotion.h"
#include "MagicPotion.h"

class ShopEvent : public Event
{
public:
	ShopEvent();
	virtual void display(vector<NovicePlayer*> &);
	~ShopEvent();
private:
	Item** itemptr;
	AxeWeapon axe;
	SwordWeapon sword;
	ShieldArmor shield;
	TunicArmor tunic;
	LifePotion life_potion;
	MagicPotion magic_potion;
	int input();
};

#endif // !SHOPEVENT_H

