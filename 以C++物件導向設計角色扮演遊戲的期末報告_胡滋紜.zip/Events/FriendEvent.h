#ifndef FRIENDEVENT_H
#define FRIENDEVENT_H

#include "Event.h"

class FriendEvent :public Event
{
public:
	FriendEvent();
	virtual void display(vector<NovicePlayer*> &);
	~FriendEvent();
};

#endif // !FRIENDEVENT_H

