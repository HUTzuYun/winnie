#include "ConsumableItems.h"

ConsumableItems::ConsumableItems(
	const int levelRequired, const string &nameIn, const string &effect,
	const string &descriptionIn, const int weightIn, const char typeIn, const int costIn)
	:Item(levelRequired, nameIn, effect, descriptionIn, weightIn, typeIn, costIn)
{
}