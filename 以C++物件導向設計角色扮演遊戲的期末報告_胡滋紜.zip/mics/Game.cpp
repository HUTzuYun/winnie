#include "Game.h"
#include <iostream>
#include <fstream>
#include "MainMenu.h"
#include "Field.h"
#include "FieldMenu.h"
#include "GoblinMonster.h"
#include "ZombieMonster.h"
#include "JWMonster.h"
#include "Battle.h"
#include "BattleMenu.h"
#include "FriendEvent.h"
#include "FairyEventh.h"
#include "ShopEvent.h"
#include "AxeWeapon.h"
#include "SwordWeapon.h"
#include "ShieldArmor.h"
#include "TunicArmor.h"
#include "LifePotion.h"
#include "MagicPotion.h"
#include "KnightPlayer.h"
#include "MagicianPlayer.h"
#include "OrcPlayer.h"
#include <stdio.h>
#include <Windows.h>
#include <conio.h>
using namespace std;

Game::Game()
{
	for (int i = 0; i < 3; i++)
	{
		battle_trigger[i] = 0;
		event_trigger[i] = 0;
	}
	file_num = 0;
}

void Game::run()
{
	char c2[10] = "maze2.txt";
	Field field2(c2, 1, 1, 10, 10, "Deciduous Forest", 1);
	FieldMenu fm2(field2);
	ZombieMonster zombie;
	zombie.setHP(100);
	zombie.setMP(100);
	ShopEvent shop;

	char c3[10] = "maze3.txt";
	Field field3(c3, 1, 1, 10, 10, "Boreal Forest", 1);
	FieldMenu fm3(field3);
	JWMonster jw;
	jw.setHP(250);
	jw.setMP(200);
	FairyEvent fairy;

	BaseMonster** monsterList = new BaseMonster*[1];
	WeaponItems* weapon_ptr = NULL;
	ArmorItems* armor_ptr = NULL;
	char c1[10] = "maze1.txt";
	filename = c1;
	Field field(c1, 1, 1, 10, 10, "Rainforest", 1);
	Field* fptr = &field;
	FieldMenu field_menu(field);
	FieldMenu* fmptr = &field_menu;
	GoblinMonster goblin;
	goblin.setHP(60);
	goblin.setMP(30);
	BaseMonster* monster_ptr = &goblin;
	FriendEvent friend_event;
	Event* event_ptr = &friend_event;

	AxeWeapon axe;
	SwordWeapon sword;
	ShieldArmor shield;
	TunicArmor tunic;
	LifePotion life;
	MagicPotion magic;
	Item* itemp[6];
	itemp[0] = &axe;
	itemp[1] = &sword;
	itemp[2] = &shield;
	itemp[3] = &tunic;
	itemp[4] = &life;
	itemp[5] = &magic;
	KnightPlayer knight(1);
	OrcPlayer orc(1, "Orc");
	MagicianPlayer magician(1, "Magician");
	NovicePlayer* ptr1 = &knight;
	NovicePlayer* ptr2 = &magician;
	NovicePlayer* ptr3 = &orc;
	string yesOrNo;
	int current_x = 1;
	int current_y = 1;
	cout << "\n1. New Game 2. Start with the saved status ( read from save.txt )" << endl;
	while (true)
	{
		cout << "\nPlease enter 1 or 2:";
		getline(cin, yesOrNo);
		if (yesOrNo.size() == 1 && (yesOrNo == "1" || yesOrNo == "2"))
			break;
	}
	cout << endl;
	system("pause");
	system("cls");
	if (yesOrNo == "2")
	{
		ifstream read_file("save.txt", ios::in);
		if (!read_file)
		{
			cerr << "File could not be open" << endl;
			exit(1);
		}
		int playernum;
		string temp;
		getline(read_file, temp, '$');
		playernum = stoi(temp);
		for (int i = 0; i < playernum; i++)
		{
			getline(read_file, temp, '$');
			if (temp == "KnightPlayer")
				player_list.push_back(ptr1);
			else if (temp == "MagicianPlayer")
				player_list.push_back(ptr2);
			else player_list.push_back(ptr3);
			getline(read_file, temp, '$');
			player_list[i]->setName(temp);
			getline(read_file, temp, '$');
			player_list[i]->setLevel(stoi(temp));
			getline(read_file, temp, '$');
			player_list[i]->setHp(stoi(temp));
			getline(read_file, temp, '$');
			player_list[i]->setMp(stoi(temp));
			getline(read_file, temp, '$');
			player_list[i]->setExp(stoi(temp));
			getline(read_file, temp, '$');
			player_list[i]->setMoney(stoi(temp));
			getline(read_file, temp, '$');
			if (temp == "Super-Axe")
				weapon_ptr = &axe;
			else if (temp == "Dragon-Sword")
				weapon_ptr = &sword;
			else weapon_ptr = NULL;
			if (temp != "None")
				player_list[i]->equipWeapon(weapon_ptr);
			getline(read_file, temp, '$');
			if (temp == "Holy Shield")
				armor_ptr = &shield;
			else if (temp == "Golden Tunic")
				armor_ptr = &tunic;
			else armor_ptr = NULL;
			if (temp != "None")
				player_list[i]->equipArmor(armor_ptr);
			getline(read_file, temp, '$');
			int backpackslot = stoi(temp);
			for (int j = 0; j < backpackslot; j++)
			{
				int k;
				getline(read_file, temp, '$');
				if (temp == "Super-Axe") k = 0;
				else if (temp == "Dragon-Sword") k = 1;
				else if (temp == "Holy Shield") k = 2;
				else if (temp == "Golden Tunic") k = 3;
				else if (temp == "Magic Fruit") k = 5;
				else if (temp == "Life Juice") k = 4;
				player_list[i]->putItem(itemp[k]);
			}
		}
		getline(read_file, temp, '$');
		file_num = stoi(temp);
		for (int i = 0; i < 3; i++)
		{
			getline(read_file, temp, '$');
			event_trigger[i] = stoi(temp);
		}
		for (int i = 0; i < 3; i++)
		{
			getline(read_file, temp, '$');
			battle_trigger[i] = stoi(temp);
		}
		getline(read_file, temp, '$');
		current_x = stoi(temp);
		getline(read_file, temp, '$');
		current_y = stoi(temp);
	}
	else
	{
		player_list.push_back(ptr1);
		player_list.push_back(ptr2);
		player_list[0]->setName(start());
		system("cls");
	}
	int exit = 0;
	if (file_num == 0)
	{
		weapon_ptr = &axe;
	}
	if (file_num == 1)
	{
		filename = c2;
		fptr = &field2;
		fmptr = &fm2;
		monster_ptr = &zombie;
		weapon_ptr = &sword;
		event_ptr = &shop;
	}
	else if (file_num == 2)
	{
		filename = c3;
		fptr = &field3;
		fmptr = &fm3;
		monster_ptr = &jw;
		weapon_ptr = NULL;
		event_ptr = &fairy;
	}
	monsterList[0] = monster_ptr;
	fptr->setPosition(current_x, current_y);

	HANDLE hOutput;                                            //���{�W
	COORD coord = { 0,0 };
	hOutput = GetStdHandle(STD_OUTPUT_HANDLE);

	while (file_num < 3)
	{
		while (exit == 0)
		{
			MainMenu main_menu(player_list);
			main_menu.display();
			fmptr->display();
			int map_symbol = fptr->getMapSymbol(fptr->getCurrentPositionX(), fptr->getCurrentPositionY());
			if (map_symbol == 199 && !battle_trigger[file_num])
			{
				Battle battle(player_list, monsterList, player_list.size(), 1);
				BattleMenu battle_menu(battle, fptr);
				system("cls");
				char next_act = battle_menu.input();
				if (next_act == '1') 
				{
					battle_menu.display();
					battle.action(player_list);
					battle_trigger[file_num] = 1;
					if (player_list[0]->getHp() == 0)
					{
						cout << "\nYou lose your life in the battle...\n"
							<< "\n--------------------�բϢۢӡ@�ݢ�Ӣ�---------------------\n" 
							<< "\nPlease press any key to end.\n" << endl;
						system("pause");
						exit = 1;
						break;
					}else if (monster_ptr->getHP() == 0 && weapon_ptr != NULL)
					{
						cout << "\n" << monster_ptr->name << " drops " << weapon_ptr->name << endl;
						cout << "\n" << player_list[0]->getName() << " gets " << weapon_ptr->name << endl;
						player_list[0]->equipWeapon(weapon_ptr);
					}
					cout << endl;
					system("pause");
				}
				else 
				{
					MainMenu main_menu(player_list);
					main_menu.display();
					fmptr->display();
					cout << "\nW -> up | S -> down | A -> left | D -> right" << endl;
					cout << "\nPlease select the next step(press w s a d).";
					bool b = false;
					while (!b)
					{
						char c = _getch();
						b = fptr->move(c);
					}
				}
				system("cls");
				MainMenu main_menu(player_list);
				main_menu.display();
				fmptr->display();
			}
			else if (map_symbol == 202 && !event_trigger[file_num])
			{
				system("cls");
				event_ptr->display(player_list);
				event_trigger[file_num] = 1;
				if (file_num == 0)
					player_list.push_back(ptr3);
				MainMenu main_menu(player_list);
				main_menu.display();
				fmptr->display();
			}
			else if (map_symbol == 201)
			{
				system("cls");
				if (!battle_trigger[file_num])
					cout << "\nYou haven't entered the battle in this area.\n"
						<< "\nHope you can beat the monster~" << endl;
				else if (!event_trigger[file_num]) 
					cout << "\nYou haven't been through the event in this area." << endl;
				else 
				{
					file_num++;
					break;
				}
				cout << endl;
				system("pause");
				system("cls");
				MainMenu main_menu(player_list);
				main_menu.display();
				fmptr->display();
			}
			char next_act = fmptr->input();
			if (next_act == 'B' || next_act == 'b')
			{
				system("cls");
				viewBackpack();
				system("cls");
			}
			else if (next_act == 'Q' || next_act == 'q')
			{
				cout << "\n\nSave current state?" << endl;
				string yesOrNo;
				while(true)
				{
				    cout << "\nEnter Y or N(Yes: Y || No: N):";
					getline(cin, yesOrNo);
					if (yesOrNo.size() == 1 && (yesOrNo == "Y" || yesOrNo == "N"))
						break;
				} 
				if (yesOrNo == "Y") 
					save(fptr->getCurrentPositionX(), fptr->getCurrentPositionY());
				exit = 1;
			}
			SetConsoleCursorPosition(hOutput, coord);
		}
		if (exit == 1) break;
		else if (file_num == 1)
		{
			filename = c2;
			fptr = &field2;
			fmptr = &fm2;
			monster_ptr = &zombie;
			monsterList[0] = monster_ptr;
			weapon_ptr = &sword;
			event_ptr = &shop;
		}else if (file_num == 2)
		{
			filename = c3;
			fptr = &field3;
			fmptr = &fm3;
			monster_ptr = &jw;
			monsterList[0] = monster_ptr;
			weapon_ptr = NULL;
			event_ptr = &fairy;
		}else 
		{
			cout << "\n~~~~~~~~~~~~~~~~~~~~~~~~~Congratulations~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n" 
				<< "\nYou beat all the monsters and save the kingdom! :)\n"
				<< "\nYou are a hero!\n" << "\nPlease press any key to end.\n"<< endl;
			system("pause");
		}
	}
	delete[] monsterList;
}

string Game::start()
{
	cout << "\nOnce upon a time, there was a wonderful kingdom called Wonderland.\n"
		<< "\nHowever, monsters in nearby forest start to come out and attack people in Wonderland recently.\n"
		<< "\nYou, as a brave knight, decide to go to the dangerous forest and kill the monsters.\n"
		<< "\nYour friend, a magician, is going to go with you." << endl;
	string sIn;
	 while(true)
	 {
		cout << "\nPlease tell me your name:";
		getline(cin, sIn);
		cout << "\nIs your name " << sIn << " ?" << endl;
		bool legal;
		string yesOrNo;
		do {
			cout << "\nEnter y or n(Yes: y || No: n):";
			getline(cin, yesOrNo);
			cout << endl;
			if (yesOrNo.size() == 1 && (yesOrNo == "y" || yesOrNo == "n"))
				legal = true;
			else legal = false;
		} while (legal == false);
		if (yesOrNo == "y") break;
	} 
	cout << sIn << "! What a good name! Ready for the adventure? Let's go! Good luck!\n" << endl;
	system("pause");
	return sIn;
}

void Game::viewBackpack() const
{
	cout << "\nBackpack weight limit: " << player_list[0]->get_backpack_weight_limit();
	cout << ".  Backpack slot limit: " << player_list[0]->get_backpack_slot_limit()
		<< ".  Backpack weight: " << player_list[0]->get_backpack_weight() << "." << endl;
	cout << "\nBackpack items:" << endl;
	for (int i = 0; i < player_list[0]->get_backpack_slot(); i++)
		cout << "\n" << i + 1 << ". " << player_list[0]->getItem(i)->name <<
		"\n\nEffect: " << player_list[0]->getItem(i)->effects << "\n\nDescription: "
		<< player_list[0]->getItem(i)->description << endl;
	cout << endl;
	system("pause");
}

void Game::save(int x, int y) const
{
	ofstream save_file("save.txt", ios::out);
	if (!save_file)
	{
		cerr << "File could not be opened" << endl;
		exit(1);
	}
	save_file << player_list.size() << "$";
	for (int i = 0; i < player_list.size(); i++)
		save_file << player_list[i]->serialize();
	save_file << file_num << "$";
	for (int i = 0; i < 3; i++)
		save_file << event_trigger[i] << "$";
	for (int i = 0; i < 3; i++)
		save_file << battle_trigger[i] << "$";
	save_file << x << "$" << y << "$";
	save_file.close();
}

Game::~Game()
{
}