#include"KnightPlayer.h"
#include "LifePotion.h"
#include "MagicPotion.h"
#include <cmath>
#include <iostream>
#include <sstream>
using namespace std;

NovicePlayer* KnightPlayer::unserialize(string s)           //static function
{
	NovicePlayer *NovicePlayerPtr = new KnightPlayer;
	stringstream ss(s);
	string temp;
	getline(ss, temp, '$');
	if (temp != "KnightPlayer")
		cout << "Warning: This string is not serialized as KnightPlayer." << endl;
	getline(ss, temp, '$');
	NovicePlayerPtr->setName(temp);
	getline(ss, temp, '$');
	NovicePlayerPtr->setLevel(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setHp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setMp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setExp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setMoney(stoi(temp));
	return NovicePlayerPtr;
}

KnightPlayer::KnightPlayer()
{
	setExp(0);
	setMoney(100);
	weapon = NULL;
	armor = NULL;
	setLevel(1);
	setHp(max_hp);
	setMp(max_mp);
	backpack_slot = backpack_weight = 0;
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
	setName("anonymous");
}

KnightPlayer::KnightPlayer(int L)
{
	setExp(0);
	setMoney(100);
	weapon = NULL;
	armor = NULL;
	setLevel(L);
	setHp(max_hp);
	setMp(max_mp);
	backpack_slot = backpack_weight = 0;
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
	setName("anonymous");
}

KnightPlayer::KnightPlayer(int L, string N)
{
	setExp(0);
	setMoney(100);
	weapon = NULL;
	armor = NULL;
	setLevel(L);
	setHp(max_hp);
	setMp(max_mp);
	backpack_slot = backpack_weight = 0;
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
	setName(N);
}

KnightPlayer::KnightPlayer(const KnightPlayer& KP)
{
	if (KP.weapon == NULL)weapon = NULL;
	else weapon = KP.weapon;
	if (KP.armor == NULL)armor = NULL;
	else armor = KP.armor;
	setLevel(KP.getLevel());
	backpack = new Item*[KP.backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = KP.backpack[i];
	setName(KP.getName());
	setHp(KP.getHp());
	setMp(KP.getMp());
	setExp(KP.getExp());
	setMoney(KP.getMoney());
	backpack_slot = KP.backpack_slot;
	backpack_weight = KP.backpack_weight;
}

void KnightPlayer::setLevel(int L)
{
	level = L;
	max_hp = 150 + 25 * L;
	max_mp = 70 + 10 * L;
	if (weapon == NULL)
		attack = 40 + 10 * L;
	else
		attack = 40 + 10 * L + weapon->attack_increment;
	if (armor == NULL)
		defense = 20 + 12 * L;
	else
		defense = 20 + 12 * L + armor->defense_increment;
	lvup_exp = ceil(pow(10, log2(L + 1)));
	backpack_weight_limit = 100 + 50 * L;
	backpack_slot_limit = 1 + L;
}

void KnightPlayer::specialSkill()       //increasing HP (level*10) points by decreasing MP (level*5) points
{
	int i = level;
	while ((getHp() + 10 < max_hp) && (getMp() - 5 > 0) && (i > 0))
	{
		setHp(getHp() + 10);
		setMp(getMp() - 5);
		--i;
	}
}

string KnightPlayer::serialize()
{
	stringstream ss;
	ss << "KnightPlayer" << "$";
	ss << getName() << "$";
	ss << getLevel() << "$";
	ss << getHp() << "$";
	ss << getMp() << "$";
	ss << getExp() << "$";
	ss << getMoney() << "$";
	ss << get_weapon() << "$";
	ss << get_armor() << "$";
	ss << get_backpack_slot() << "$";
	for (int i = 0; i < get_backpack_slot(); i++)
		ss << getItem(i)->name << "$";
	string s;
	s = ss.str();
	return s;
}

