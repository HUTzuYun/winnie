#ifndef NOVICEPLAYER_H
#define NOVICEPLAYER_H

#include <string>
#include "ArmorItems.h"
#include "WeaponItems.h"
#include "ConsumableItems.h"
#include "Item.h"
using namespace std;

class NovicePlayer
{
public:
	NovicePlayer();                          //Constructors
	NovicePlayer(int);
	NovicePlayer(int, string);
	NovicePlayer(const NovicePlayer&);       //copy constructor
	virtual void setLevel(int);                      //Set & Get Functions
	int getLevel() const;
	void setName(string);
	string getName() const;
	void setHp(int);
	int getHp() const;
	void setMp(int);
	int getMp() const;
	void setExp(int);
	int getExp() const;
	void setMoney(int);               
	int getMoney() const;
	int getAttack() const;
	int getDefense() const;
	virtual void specialSkill();
	virtual string serialize();
	bool equipWeapon(WeaponItems*);
	bool equipArmor(ArmorItems*);
	bool useConsumable(string);
	bool putItem(Item*);
	Item* takeItem(int);
	Item* getItem(int) const;
	int get_backpack_weight_limit() const;
	int get_backpack_slot_limit() const;
	int get_backpack_weight() const;
	int get_backpack_slot() const;
	string get_weapon() const;
	string get_armor() const;
	virtual ~NovicePlayer();

	static NovicePlayer* unserialize(string);
protected:
	int level;
	int attack; 
	int defense; 
	int max_hp; 
	int max_mp; 
	int lvup_exp;
	int backpack_weight_limit;
	int backpack_slot_limit;
	int backpack_weight;
	int backpack_slot;
	WeaponItems* weapon;
	ArmorItems* armor;
	Item** backpack;
private:
	string name;
	int hp;                           //[0, max_hp]
	int mp;                           //[0, max_mp]
	int exp;                          //[0, lvup_exp]
	int money;                        //>=0
};

#endif // !NOVICEPLAYER_H

