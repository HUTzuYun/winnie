#ifndef ARMORITEMS_H
#define ARMORITEMS_H

#include "Item.h"

class ArmorItems : public Item
{
public:
	ArmorItems(const int, const string&, const string&, const string&, const int, const char, const int, const int);
	const int defense_increment;         //the number of increment on defense after equipping this item
	virtual ~ArmorItems() {}
};

#endif // !ARMORITEMS_H

