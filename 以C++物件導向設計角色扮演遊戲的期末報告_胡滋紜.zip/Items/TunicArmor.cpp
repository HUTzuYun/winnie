#include "TunicArmor.h"

TunicArmor::TunicArmor()
	: ArmorItems(1, "Golden Tunic", "defense + 80", "A bulletproof high quality tunic.", 80, 'a', 80, 80)
{
}