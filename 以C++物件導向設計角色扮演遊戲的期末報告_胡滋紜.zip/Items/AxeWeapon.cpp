#include "AxeWeapon.h"

AxeWeapon::AxeWeapon()
	: WeaponItems(2, "Super-Axe", "Attack + 50", 
		"It is made of a kind of special material. Only brave man can use it effectively.", 100, 'w', 80, 50)
{
}