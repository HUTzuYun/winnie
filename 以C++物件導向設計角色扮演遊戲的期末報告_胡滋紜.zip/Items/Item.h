#ifndef ITEM_H
#define ITEM_H

#include <string>
using namespace std;

class Item
{
public:
	Item(const int, const string&, const string&, const string&, const int, const char, const int);
	const int level_required;   // level limit of equip/use this item
	const string name;          // the name of this item
	const string effects;             // a short description of its effect
	const string description;         // a short description of this item
	const int weight;                 // the weight of the item
	const char type;
	const int cost;
	virtual ~Item() {}
};

#endif // !ITEM_H

