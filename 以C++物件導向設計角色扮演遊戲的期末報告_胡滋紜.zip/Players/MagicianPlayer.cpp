#include "MagicianPlayer.h"
#include <cmath>
#include <iostream>
#include <sstream>
using namespace std;

NovicePlayer* MagicianPlayer::unserialize(string s)           //static function
{
	NovicePlayer *NovicePlayerPtr = new MagicianPlayer;
	stringstream ss(s);
	string temp;
	getline(ss, temp, '$');
	if (temp != "MagicianPlayer")
		cout << "Warning: This string is not serialized as MagicianPlayer." << endl;
	getline(ss, temp, '$');
	NovicePlayerPtr->setName(temp);
	getline(ss, temp, '$');
	NovicePlayerPtr->setLevel(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setHp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setMp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setExp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setMoney(stoi(temp));
	return NovicePlayerPtr;
}

MagicianPlayer::MagicianPlayer()
{
	setExp(0);
	setMoney(100);
	weapon = NULL;
	armor = NULL;
	setLevel(1);
	setHp(max_hp);
	setMp(max_mp);
	backpack_slot = backpack_weight = 0;
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
	setName("anonymous");
}

MagicianPlayer::MagicianPlayer(int L)
{
	setExp(0);
	setMoney(100);
	weapon = NULL;
	armor = NULL;
	setLevel(L);
	setHp(max_hp);
	setMp(max_mp);
	backpack_slot = backpack_weight = 0;
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
	setName("anonymous");
}

MagicianPlayer::MagicianPlayer(int L, string N)
{
	setExp(0);
	setMoney(100);
	weapon = NULL;
	armor = NULL;
	setLevel(L);
	setHp(max_hp);
	setMp(max_mp);
	backpack_slot = backpack_weight = 0;
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
	setName(N);
}

MagicianPlayer::MagicianPlayer(const MagicianPlayer& MP)
{
	if (MP.weapon == NULL)weapon = NULL;
	else weapon = MP.weapon;
	if (MP.armor == NULL)armor = NULL;
	else armor = MP.armor;
	setLevel(MP.getLevel());
	backpack = new Item*[MP.backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = MP.backpack[i];
	setName(MP.getName());
	setHp(MP.getHp());
	setMp(MP.getMp());
	setExp(MP.getExp());
	setMoney(MP.getMoney());
	backpack_slot = MP.backpack_slot;
	backpack_weight = MP.backpack_weight;;
}

void MagicianPlayer::setLevel(int L)
{
	level = L;
	max_hp = 120 + 15 * L;
	max_mp = 100 + 15 * L;
	if (weapon == NULL)
		attack = 30 + 8 * L;
	else
		attack = 30 + 8 * L + weapon->attack_increment;
	if (armor == NULL)
		defense = 20 + 7 * L;
	else
		defense = 20 + 7 * L + armor->defense_increment;
	lvup_exp = ceil(pow(10, log2(L + 1)));
	backpack_weight_limit = 100 + 50 * L;
	backpack_slot_limit = 1 + L;
}

void MagicianPlayer::specialSkill()      //increasing MP (level*10) points by decreasing HP (level*5) points
{
	int i = level;
	while ((getMp() + 10 < max_mp) && (getHp() - 5 > 0) && (i > 0))
	{
		setHp(getHp() - 5);
		setMp(getMp() + 10);
		--i;
	}
}

string MagicianPlayer::serialize()
{
	stringstream ss;
	ss << "MagicianPlayer" << "$";
	ss << getName() << "$";
	ss << getLevel() << "$";
	ss << getHp() << "$";
	ss << getMp() << "$";
	ss << getExp() << "$";
	ss << getMoney() << "$";
	ss << get_weapon() << "$";
	ss << get_armor() << "$";
	ss << get_backpack_slot() << "$";
	for (int i = 0; i < get_backpack_slot(); i++)
		ss << getItem(i)->name << "$";
	string s;
	s = ss.str();
	return s;
}
