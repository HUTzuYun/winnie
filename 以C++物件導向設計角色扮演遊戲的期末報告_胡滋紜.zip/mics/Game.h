#ifndef GAME_H
#define GAME_H

#include <vector>
#include <string>
using namespace std;

class NovicePlayer;

class Game
{
public:
	Game();
	void run();
	~Game();
private:
	vector<NovicePlayer*> player_list;
	bool battle_trigger[3];
	bool event_trigger[3];
	int file_num;
	char* filename;
	void viewBackpack() const;
	void save(int, int) const;
	string start();
};

#endif // !GAME_H

