#ifndef SHIELDARMOR_H
#define SHIELDARMOR_H

#include "ArmorItems.h"

class ShieldArmor : public ArmorItems
{
public:
	ShieldArmor();
	~ShieldArmor() {}
};

#endif // !SHIELDARMOR_H

