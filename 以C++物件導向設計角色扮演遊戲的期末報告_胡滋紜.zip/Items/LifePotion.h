#ifndef LIFEPOTION_H
#define LIFEPOTION_H

#include "ConsumableItems.h"

class LifePotion : public ConsumableItems
{
public:
	LifePotion();
	~LifePotion();
};

#endif // !LIFEPOTION

