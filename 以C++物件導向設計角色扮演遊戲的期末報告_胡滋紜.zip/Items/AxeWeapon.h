#ifndef AXEWEAPON_H
#define AXEWEAPON_H

#include "WeaponItems.h"

class AxeWeapon : public WeaponItems
{
public:
	AxeWeapon();
	~AxeWeapon() {}
};

#endif // !AXEWEAPON_H

