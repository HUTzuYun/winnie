#ifndef BASEMONSTER_H
#define BASEMONSTER_H

#include <string>

using namespace std;

class BaseMonster
{
public:
	BaseMonster(string , int , int , int , int , int , int);
	const string name;
	const int attack;
	const int defense;
	const int exp;
	const int money;
	const int max_hp;
	const int max_mp;
	virtual ~BaseMonster();
	void setHP(int);
	int getHP() const;
	void setMP(int);
	int getMP() const;
	virtual string serialize() = 0;

	static int getInstanceCount();
protected:
	static int count;
private:
	int hp;
	int mp;
};

#endif
