#ifndef CONSUMABLEITEMS_H
#define CONSUMABLEITEMS_H

#include "Item.h"

class ConsumableItems : public Item
{
public:
	ConsumableItems(const int, const string&, const string&, const string&, const int, const char, const int);
	virtual ~ConsumableItems() {}
};

#endif // !CONSUMABLEITEMS_H

