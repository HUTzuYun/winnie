#ifndef MAINMENU_H
#define MAINMENU_H

#include "Menu.h"
#include <vector>
using namespace std;

class NovicePlayer;

class MainMenu : public Menu
{
public:
	MainMenu(vector<NovicePlayer*> &);
	virtual void display() const;
	virtual char input();
	virtual ~MainMenu();
private:
	NovicePlayer** playerList;
	int playerNum;
};

#endif // !MAINMENU_H

