#ifndef FAIRYEVENT_H
#define FAIRYEVENT_H

#include "Event.h"
class Item;
class ArmorItems;

class FairyEvent : public Event
{
public:
	FairyEvent();
	virtual void display(vector<NovicePlayer*> &);
	~FairyEvent();
private:
	ArmorItems* shield;
	ArmorItems* tunic;
	Item* life_potion;
};

#endif // !FAIRYEVENT_H