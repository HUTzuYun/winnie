#ifndef TUNICARMOR_H
#define TUNICARMOR_H

#include"ArmorItems.h"

class TunicArmor : public ArmorItems
{
public:
	TunicArmor();
	~TunicArmor() {};
};

#endif // !TUNICARMOR_H

