#ifndef ZOMBIEMONSTER_H
#define ZOMBIEMONSTER_H

#include "BaseMonster.h"

class ZombieMonster : public BaseMonster
{
public:
	ZombieMonster();
	virtual string serialize();
	~ZombieMonster();

	static BaseMonster* unserialize(string);
};

#endif
