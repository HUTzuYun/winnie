#include "ZombieMonster.h"
#include <sstream>
#include <iostream>
using namespace std;

BaseMonster* ZombieMonster::unserialize(string s)
{
	BaseMonster *BaseMonsterPtr = new ZombieMonster;
	stringstream ss(s);
	string temp;
	getline(ss, temp, '$');
	if (temp != "ZombieMonster")
		cout << "Warning: This string is not serialized as ZombieMonster." << endl;
	getline(ss, temp, '$');
	BaseMonsterPtr->setHP(stoi(temp));
	getline(ss, temp, '$');
	BaseMonsterPtr->setMP(stoi(temp));
	return BaseMonsterPtr;
}

ZombieMonster::ZombieMonster()
	:BaseMonster("ZombieMonster", 50, 65, 17, 65, 150, 30)
{
}

string ZombieMonster::serialize()
{
	stringstream ss;
	ss << name << "$" << getHP() << "$" << getMP() << "$";
	string s = ss.str();
	return s;
}

ZombieMonster::~ZombieMonster()
{
	--count;
}