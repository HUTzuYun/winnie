#include "MainMenu.h"
#include "NovicePlayer.h"
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

MainMenu::MainMenu(vector<NovicePlayer*>& playerPtr)
{
	playerNum = playerPtr.size();
	playerList = new NovicePlayer*[playerNum];
	for (int i = 0; i < playerNum; i++)
		playerList[i] = playerPtr[i];
}

MainMenu::~MainMenu()
{
	delete[] playerList;
}

void MainMenu::display() const
{
	cout << "\n------------------------------------------PLAYERS' INFORMATIONS----------------------------------------------" << endl;
	cout << "\n" << left << setw(12) << "Name" << setw(8) << "Level"
		<< setw(8) << "Hp" << setw(8) << "Mp" << setw(8) << "Exp"
		<< setw(8) << "Money" << setw(8) << "Attack" << setw(8) <<
		"Defense" << setw(13) << "Weapon" << setw(13) << "Armor"
		<< right << setw(15) << "Backpack slots" << endl;
	for (int i = 0; i < playerNum; i++)
		cout << "\n" << left << setw(12) << playerList[i]->getName() << setw(8) << playerList[i]->getLevel()
		<< setw(8) << playerList[i]->getHp() << setw(8) << playerList[i]->getMp() << setw(8)
		<< playerList[i]->getExp() << setw(8) << playerList[i]->getMoney() << setw(8)
		<< playerList[i]->getAttack() << setw(8) << playerList[i]->getDefense() << setw(13)
		<< playerList[i]->get_weapon() << setw(13) << playerList[i]->get_armor() << right <<
		setw(15) << playerList[i]->get_backpack_slot() << endl;
	cout << "\n-------------------------------------------------------------------------------------------------------------" << endl;
}

char MainMenu::input()
{
	return 'c';
}