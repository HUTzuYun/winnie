#include "Field.h"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <windows.h>
#include <iterator>
#include <ctime>
using namespace std;

Field::Field(vector<vector<int>> mapData, int current_x, int current_y, int visionWidth, int visionHeight, string mapName, int numOfBattle)
{
	row = mapData.size();
	col = mapData[0].size();
	map_data = new int*[row];
	for (int i = 0; i < row; i++)
		map_data[i] = new int[col];
	for (int i = 0; i < row; i++)
		for (int j = 0; j < col; j++)
			map_data[i][j] = mapData[i][j];
	srand(time(0));
	int num = 0;
	while (num < numOfBattle)                    
	{
		int battleX = rand() % row;
		int battleY = rand() % col;
		if (map_data[battleX][battleY] == 0)
		{
			map_data[battleX][battleY] = 199;
			++num;
		}
	}
	setPosition(current_x, current_y);
	vision_width = visionWidth;
	vision_height = visionHeight;
	map_name = mapName;
}
Field::Field(const char* fileName, int current_x, int current_y, int visionWidth, int visionHeight, string mapName, int numOfBattle)
{
	string str = string(fileName);
	ifstream inClientFile;
	inClientFile.open(str);
	if (!inClientFile)
	{
		cerr << "File could not be opened" << endl;
		exit(1);
	}
	string temp;
	getline(inClientFile, temp, ',');
	col = stoi(temp);
	getline(inClientFile, temp, '\n');
	row = stoi(temp);
	map_data = new int*[row];
	for (int i = 0; i < row; i++)
		map_data[i] = new int[col];
	for (int i = 0; i < row; i++)
		for (int j = 0; j < col; j++)
		{
			if (j == col - 1)getline(inClientFile, temp, '\n');
			else getline(inClientFile, temp, ',');
			map_data[i][j] = stoi(temp);
		}
	srand(time(0));
	int num = 0;
	while (num < numOfBattle)
	{
		int battleX = rand() % row;
		int battleY = rand() % col;
		if (map_data[battleX][battleY] == 0)
		{
			map_data[battleX][battleY] = 199;
			++num;
		}
	}
	setPosition(current_x, current_y);
	vision_width = visionWidth;
	vision_height = visionHeight;
	map_name = mapName;
}
bool Field::move(char c)              //The return value indicates whether this move is legal or not
{
	switch (c)
	{
	case 'W':
	case 'w':
		return moveUp();
		break;
	case 'S':
	case 's':
		return moveDown();
		break;
	case 'A':
	case 'a':
		return moveLeft();
		break;
	case 'D':
	case 'd':
		return moveRight();
		break;
	default:
		return false;
		break;
	}
}
bool Field::moveUp()
{
	int xTemp = getCurrentPositionX();
	setPosition(xTemp - 1, getCurrentPositionY());
	if (xTemp == getCurrentPositionX())
		return false;
	else
		return true;
}
bool Field::moveDown()
{
	int xTemp = getCurrentPositionX();
	setPosition(xTemp + 1, getCurrentPositionY());
	if (xTemp == getCurrentPositionX())
		return false;
	else
		return true;
}
bool Field::moveLeft()
{
	int yTemp = getCurrentPositionY();
	setPosition(getCurrentPositionX(), yTemp - 1);
	if (yTemp == getCurrentPositionY())
		return false;
	else
		return true;
}
bool Field::moveRight()
{
	int yTemp = getCurrentPositionY();
	setPosition(getCurrentPositionX(), yTemp + 1);
	if (yTemp == getCurrentPositionY())
		return false;
	else
		return true;
}
int Field::getCurrentPositionX() const
{
	return current_position_x;
}
int Field::getCurrentPositionY() const
{
	return current_position_y;
}
int Field::getVisionWidth() const
{
	return vision_width;
}
int Field::getVisionHeight() const
{
	return vision_height;
}
string Field::getMapName() const
{
	return map_name;
}
int Field::getMapSymbol(int x, int y)                //Parameter is the position (x,y)
{
	return map_data[x][y];
}
void Field::setPosition(int x, int y)
{
	enum {WALL = 1, BOUNS = 202, WIN = 201, BATTLE = 199, PAVEMENTS = 0, START = 200};
	switch (map_data[x][y])
	{
	case WALL:
		break;
	case BOUNS:
	case BATTLE:
	case WIN:
	case PAVEMENTS:
	case START:
		current_position_x = x;
		current_position_y = y;
		break;
	default:
		cout << "Invalid setPostion(" << x << ", " << y << ")" << endl;
		break;
	}
}
void Field::setMapSymbol(int symbol, int x, int y)    //The first parameter is symbol, the rest are position (x,y)
{
	map_data[x][y] = symbol;
}

void Field::setVisionSize(int visionX, int visionY)
{
	vision_width = visionX;
	vision_height = visionY;
}
void SetColor(int color = 7)
{
	HANDLE hConsole;
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, color);
}
void Field::display() const
{
	int startX, endX, startY, endY;
	if ((getVisionHeight() % 2) == 0)
	{
		startX = getCurrentPositionX() - getVisionHeight() / 2;
		endX = getCurrentPositionX() + getVisionHeight() / 2;
	}else
	{
		startX = getCurrentPositionX() - (getVisionHeight() - 1) / 2;
		endX = getCurrentPositionX() + (getVisionHeight() + 1) / 2;
	}
	if ((getVisionWidth() % 2) == 0)
	{
		startY = getCurrentPositionY() - getVisionWidth() / 2;
		endY = getCurrentPositionY() + getVisionWidth() / 2;
	}else
	{
		startY = getCurrentPositionY() - (getVisionWidth() - 1) / 2;
		endY = getCurrentPositionY() + (getVisionWidth() + 1) / 2;
	}
	for (int i = startX; i < endX; i++)
	{
		for (int j = startY; j < endY; j++)
		{
			if (i < 0 || j < 0 || i >= row || j >= col)
				cout << setw(2) << " ";
			else if (map_data[i][j] == 1)
			{
				SetColor(116);
				printf("��");
			}
			else if (i == getCurrentPositionX() && j == getCurrentPositionY())
			{
				SetColor(285);
				cout << setw(2) << "*";
			}
			else if (map_data[i][j] == 200)
			{
				SetColor(224);
				cout << setw(2) << "S";
			}
			else if (map_data[i][j] == 201)
			{
				SetColor(177);
				cout << setw(2) << "E";
			}
			else if (map_data[i][j] > 201)
			{
				SetColor(208);
				cout << setw(2) << "?";
			}
			else if (map_data[i][j] == 0)
			{
				SetColor(115);
				printf("��");
			}
			else if (map_data[i][j] == 199)
			{
				SetColor(240);
				cout << setw(2) << "!";
			}
			SetColor();
		}
		cout << endl;
	}
}
Field::~Field()
{
	for (int i = 0; i < row; i++)
		delete[] map_data[i];
	delete[] map_data;
}