#ifndef WEAPONITEMS_H
#define WEAPONITEMS_H

#include "Item.h"

class WeaponItems : public Item
{
public:
	WeaponItems(const int, const string&, const string&, const string&, const int, const char, const int, const int);
	const int attack_increment;          //the number of increment on attack after equipping this item
	virtual ~WeaponItems() {}
};

#endif // !WEAPONITEMS_H

