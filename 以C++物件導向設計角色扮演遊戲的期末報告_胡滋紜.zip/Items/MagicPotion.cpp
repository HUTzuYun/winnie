#include "MagicPotion.h"

MagicPotion::MagicPotion()
	:ConsumableItems(1, "Magic Fruit", "Mp + 50", "Have a taste of it. It's yummy.", 30, 'c', 50)
{
}

MagicPotion::~MagicPotion()
{
}