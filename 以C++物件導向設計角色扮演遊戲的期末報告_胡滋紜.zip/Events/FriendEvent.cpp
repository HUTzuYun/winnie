#include "FriendEvent.h"
#include <iostream>
#include "NovicePlayer.h"
using namespace std;

FriendEvent::FriendEvent()
{
}

void FriendEvent::display(vector<NovicePlayer*> & player_list)
{
	cout << "\nYou meet a new friend...\n" << endl;
	system("pause");
	system("cls");
	cout << "\nOrc: Hi! I am Orc. I would like to go with you and beat the monsters." << endl;
	cout << "\n" << player_list[0]->getName() << ": Nice to meet you! I'm " << player_list[0]->getName() << ". " 
		<< "I'm glad to have such a strong partner. Let's move on!" << endl;
	cout << "\nOrc: OK! :)\n" << endl;
	system("pause");
	system("cls");
}

FriendEvent::~FriendEvent()
{
}