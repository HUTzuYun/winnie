#include "FieldMenu.h"
#include "Field.h"
#include <iostream>
#include <conio.h>
using namespace std;

FieldMenu::FieldMenu(Field &f)
{
	field = &f;
}

void FieldMenu::display() const
{
	cout << endl;
	field->display();
	cout << "\nYou are now at(" << field->getCurrentPositionX() << ", " << field->getCurrentPositionY()
		<< ") of " << field->getMapName() << endl;
}

char FieldMenu::input()
{
	bool legal;
	cout << "\nW -> up | S -> down | A -> left | D -> right | B -> View backpack | Q -> to quit" << endl;
	cout << "\nPlease press w, s, a, d to move, b to view backpack and q to quit.";
	do {
		char c;
		legal = true;
		c = _getch();
		if (c == 'Q' || c == 'B' || c == 'q' || c == 'b')
			return c;
		else
		{
			legal = field->move(c);
			return 'N';
		}
	} while (legal == false);
}

FieldMenu::~FieldMenu()
{
}