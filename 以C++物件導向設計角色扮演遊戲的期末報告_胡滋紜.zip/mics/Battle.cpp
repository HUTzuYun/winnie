#include "Battle.h"
#include "JWMonster.h"
#include "ZombieMonster.h"
#include "GoblinMonster.h"
#include "LifePotion.h"
#include "MagicPotion.h"
#include <iostream>
#include <iomanip>
using namespace std;

Battle::Battle(vector<NovicePlayer*>& playerPtr, BaseMonster** monsterPtr, int nPl, int nMon, int tLimit)  //Type A
{ 
	turnLimit = tLimit;
	turnNum = 0;
 	attackNum = 0;
	playerNum = nPl;
	monsterNum = nMon;
	actionList = new Character[nPl + nMon];
	for (int i = 0; i < nPl; i++)
	{
		actionList[i].type = 'p';
		actionList[i].instance = playerPtr[i];     
	}		                                           
	for (int i = nPl; i < nPl + nMon; i++)
	{
		actionList[i].type = 'm';
		actionList[i].instance = *(monsterPtr + i - nPl);
	}		
}

Battle::Battle(vector<NovicePlayer*>& playerPtr, BaseMonster** monsterPtr, int nPl, int nMon) //Constructor (Type A)
{
	turnLimit = 0;
	turnNum = 0;
	attackNum = 0;
	playerNum = nPl;
	monsterNum = nMon;
	actionList = new Character[nPl + nMon];
	for (int i = 0; i < nPl; i++)
	{
		actionList[i].type = 'p';
		actionList[i].instance = playerPtr[i];
	}
	for (int i = nPl; i < nPl + nMon; i++)
	{
		actionList[i].type = 'm';
		actionList[i].instance = *(monsterPtr + i - nPl);
	}
}

Battle::Battle(vector<NovicePlayer*>& playerPtr, int nPl)              //Constructor (Type B)
{
	turnLimit = 0;
	turnNum = 0;
	attackNum = 0;
	playerNum = nPl;
	monsterNum = 3;
	actionList = new Character[nPl + monsterNum];
	for (int i = 0; i < nPl; i++)
	{
		actionList[i].type = 'p';
		actionList[i].instance = playerPtr[i];
	}
	monsterList = new BaseMonster*[3];
	goblin.setHP(goblin.max_hp);
	goblin.setMP(goblin.max_mp);
	ptrG = &goblin;
	zombie.setHP(zombie.max_hp);
	zombie.setMP(zombie.max_mp);
	ptrZ = &zombie;
	jw.setHP(jw.max_hp);
	jw.setMP(jw.max_mp);
	ptrJW = &jw;
	monsterList[0] = ptrG;
	monsterList[1] = ptrZ;
	monsterList[2] = ptrJW;
	for (int i = nPl; i < nPl + monsterNum; i++)
	{
		actionList[i].type = 'm';
		actionList[i].instance = *(monsterList + i - nPl);
	}
}

Battle::Battle(vector<NovicePlayer*>& playerPtr, int nPl, int tLimit)              //Constructor (Type B)
{
	turnLimit = tLimit;
	turnNum = 0;
	attackNum = 0;
	playerNum = nPl;
	monsterNum = 3;
	actionList = new Character[nPl + monsterNum];
	for (int i = 0; i < nPl; i++)
	{
		actionList[i].type = 'p';
		actionList[i].instance = playerPtr[i];
	}
	monsterList = new BaseMonster*[3];
	goblin.setHP(goblin.max_hp);
	goblin.setMP(goblin.max_mp);
	ptrG = &goblin;
	zombie.setHP(zombie.max_hp);
	zombie.setMP(zombie.max_mp);
	ptrZ = &zombie;
	jw.setHP(jw.max_hp);
	jw.setMP(jw.max_mp);
	ptrJW = &jw;
	monsterList[0] = ptrG;
	monsterList[1] = ptrZ;
	monsterList[2] = ptrJW;
	for (int i = nPl; i < nPl + monsterNum; i++)
	{
		actionList[i].type = 'm';
		actionList[i].instance = *(monsterList + i - nPl);
	}
}

void Battle::action(vector<NovicePlayer*>& player_list)
{
	while (getMonsterCount(true) && getPlayerCount(true))
	{
		if (getTurnLimit() != 0 && getTurnCount() == getTurnLimit())
			break;
		cout << endl;
		system("pause");
		system("cls");
		NovicePlayer *tempPlayer;
		BaseMonster *tempMonster;
		if (actionList[attackNum].type == 'p')
		{
			tempPlayer = static_cast<NovicePlayer*>(actionList[attackNum].instance);
			cout << "\n" <<tempPlayer->getName() << "'s turn to attack!" << endl;
			cout << "\n--" <<tempPlayer->getName() << "'s information--" << endl;
			cout << "\n" << setw(12) << "Level: " << tempPlayer->getLevel() << endl;
			cout << "\n" << setw(12) << "Hp: " << tempPlayer->getHp() << endl;
			cout << "\n" << setw(12) << "Mp: " << tempPlayer->getMp() << endl;
			cout << "\n" << setw(12) << "Attack: " << tempPlayer->getAttack() << endl;
			cout << "\n" << setw(12) << "Defense: " << tempPlayer->getDefense() << endl;
			cout << "\n" << setw(12) << "Exp: " << tempPlayer->getExp() << endl;
			cout << "\n" << setw(12) << "Money: " << tempPlayer->getMoney() << endl;
			cout << endl;
			system("pause");
			for (int i = getPlayerCount(); i < getPlayerCount() + getMonsterCount(); i++)
			{
				tempMonster = static_cast<BaseMonster*>(actionList[i].instance);
				if (actionList[i].alive == 0)
					continue;
				else if (tempMonster->defense < tempPlayer->getAttack())
				{
					cout << "\n" << tempMonster->name << " is going to be attacked by " << tempPlayer->getName() << endl;
					cout << "\nBefore attack " << tempMonster->name << "'s Hp: " << tempMonster->getHP() << endl;
					tempMonster->setHP(tempMonster->getHP() - tempPlayer->getAttack() + tempMonster->defense);
					cout << "\nAfter attack " << tempMonster->name << "'s Hp: " << tempMonster->getHP() << endl;
					if (tempMonster->getHP() == 0)
					{
						cout << "\n" << tempMonster->name << " is killed by " << tempPlayer->getName() << "!" << endl;
						actionList[i].alive = 0;
						tempPlayer->setMoney(tempPlayer->getMoney() + tempMonster->money);
						cout << "\n" << tempMonster->name << " drops money $" << tempMonster->money << "." << endl;
						cout << "\n" << tempPlayer->getName() << " gets $" << tempMonster->money << "." << endl;
					}
				} else 
					cout << "\n" << tempMonster->name << "'s defense ( " << tempMonster->defense << " ) greater than " <<
					tempPlayer->getName() << "'s attack ( " << tempPlayer->getAttack() << " )" << endl;
			}
			tempPlayer->setExp(tempPlayer->getExp() + 10);
			if (getMonsterCount(true) == 0)
				break;
		}else if (actionList[attackNum].type == 'm') 
		{
			tempMonster = static_cast<BaseMonster*>(actionList[attackNum].instance);
			cout << "\n" << tempMonster->name << "'s turn to attack!" << endl;
			cout << "\n--" << tempMonster->name << "'s information--" << endl;
			cout << "\n" << setw(12) << "Hp: " << tempMonster->getHP() << endl;
			cout << "\n" << setw(12) << "Mp: " << tempMonster->getMP() << endl;
			cout << "\n" << setw(12) << "Attack: " << tempMonster->attack << endl;
			cout << "\n" << setw(12) << "Defense: " << tempMonster->defense << endl;
			cout << "\n" << setw(12) << "Exp: " << tempMonster->exp << endl;
			cout << "\n" << setw(12) << "Money: " << tempMonster->money << endl;
			cout << endl;
			system("pause");
			for (int i = 0; i < getPlayerCount(); i++)
			{
				tempPlayer = static_cast<NovicePlayer*>(actionList[i].instance);
				if (actionList[i].alive == 0)
					continue;
				if (tempMonster->attack > tempPlayer->getDefense())
				{
					cout << "\n" << tempPlayer->getName() << " is going to be attacked by " << tempMonster->name << endl;
					cout << "\nBefore attack " << tempPlayer->getName() << "'s Hp: " << tempPlayer->getHp() << endl;
					while (i == 0)
					{
						cout << "\n1.Use consumable items 2.Perform special skill 3.No thanks, I don't need it." << endl;
						cout << "\nPlease Enter 1 or 2 or 3:";
						string str;
						getline(cin, str);
						if (str == "1")
						{
							while (true) {
								cout << "\nEnter 1 or 2 (1. Magic Fruit 2. Life Juice):";
								string s;
								getline(cin, s);
								if (s == "2") {
									LifePotion life;
									if (tempPlayer->useConsumable(life.name) == true)
										cout << "\nAfter drinking Life Juice " << tempPlayer->getName() << "'s Hp: " <<
										tempPlayer->getHp() << endl;
									else cout << "\nYou do not have Life Juice. No effect on Hp." << endl;
									break;
								}
								else if (s == "1") {
									MagicPotion m;
									if (tempPlayer->useConsumable(m.name) == true)
										cout << "\nAfter eating Magic Fruit " << tempPlayer->getName() << "'s Mp: " <<
										tempPlayer->getMp() << endl;
									else cout << "\nYou do not have Magic Fruit. No effect on Mp." << endl;
									break;
								}
							}
							cout << endl;
							system("pause");
							system("cls");
							break;
						}
						else if (str == "2")
						{
							tempPlayer->specialSkill();
							cout << "\nAfter performing special skill " << tempPlayer->getName() << "'s Hp: " <<
								tempPlayer->getHp() << endl;
							cout << endl;
							system("pause");
							system("cls");
							break;
						}
						else if (str == "3") 
						{
							cout << endl;
							system("pause");
							system("cls");
							break;
						}
					}
					tempPlayer->setHp(tempPlayer->getHp() - tempMonster->attack + tempPlayer->getDefense());
					cout << "\nAfter attack " << tempPlayer->getName() << "'s Hp: " << tempPlayer->getHp() << endl;
					if (tempPlayer->getHp() == 0)
					{
						cout << "\n" << tempPlayer->getName() << " is killed by " << tempMonster->name << "." << endl;
						actionList[i].alive = 0;
						if (i != 0)
							player_list.erase(player_list.begin() + i);
					}
				}
				else
					cout << "\n" << tempPlayer->getName() << "'s defense ( " << tempPlayer->getDefense() <<	" ) greater than "
					<< tempMonster->name << "'s attack ( " << tempMonster->attack << " )" << endl;
				if (actionList[i].alive)
					tempPlayer->setExp(tempPlayer->getExp() + 5);
			}
			if (actionList[0].alive == 0) {
				system("cls");
				break;
			}
		}
		nextActor();
	}
}

void Battle::nextActor()
{
	int next = 0;
	while (!next)
	{
		++attackNum;
		if (attackNum == getPlayerCount() + getMonsterCount())
		{
			attackNum = 0;
			++turnNum;
			if (actionList[0].alive) 
				next = 1;
		}
		else if (actionList[attackNum].alive)
			next = 1;
	}
}

int Battle::getTurnCount() const
{
	return turnNum;
}

int Battle::getTurnLimit() const
{
	return turnLimit;
}

Character Battle::getCurrentActor()
{
	return actionList[attackNum];
}

Character* Battle::getPlayers()
{
	Character *returnList = new Character[getPlayerCount()];
	for (int i = 0; i < getPlayerCount(); i++)
		returnList[i] = actionList[i];
	return returnList;
}

Character* Battle::getMonsters()
{
	Character *returnList = new Character[getMonsterCount()];
	for (int i = 0; i < getMonsterCount(); i++)
		returnList[i] = actionList[getPlayerCount() + i];
	return returnList;
}

int Battle::getPlayerCount() const
{
	return playerNum;
}

int Battle::getPlayerCount(bool) const
{
	int count = 0;
	for (int i = 0; i < getPlayerCount(); i++)
		if (actionList[i].alive) count++;
	return count;
}

int Battle::getMonsterCount() const
{
	return monsterNum;
}

int Battle::getMonsterCount(bool) const
{
	int count = 0;
	for (int i = getPlayerCount(); i < getPlayerCount() + getMonsterCount(); i++)
		if (actionList[i].alive) count++;
	return count;
}

Battle::~Battle()
{
	delete[] actionList;
	delete[] monsterList;
}