#ifndef MAGICPOTION_H
#define MAGICPOTION_H

#include "ConsumableItems.h"

class MagicPotion : public ConsumableItems
{
public:
	MagicPotion();
	~MagicPotion();
};

#endif // !MAGICPOTION_H

