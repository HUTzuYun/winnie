#include "OrcPlayer.h"
#include <cmath>
#include <iostream>
#include <sstream>
using namespace std;

NovicePlayer* OrcPlayer::unserialize(string s)           //static function
{
	NovicePlayer *NovicePlayerPtr = new OrcPlayer;
	stringstream ss(s);
	string temp;
	getline(ss, temp, '$');
	if (temp != "OrcPlayer")
		cout << "Warning: This string is not serialized as OrcPlayer." << endl;
	getline(ss, temp, '$');
	NovicePlayerPtr->setName(temp);
	getline(ss, temp, '$');
	NovicePlayerPtr->setLevel(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setHp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setMp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setExp(stoi(temp));
	getline(ss, temp, '$');
	NovicePlayerPtr->setMoney(stoi(temp));
	return NovicePlayerPtr;
}

OrcPlayer::OrcPlayer()
{
	setExp(0);
	setMoney(100);
	weapon = NULL;
	armor = NULL;
	setLevel(1);
	setHp(max_hp);
	setMp(max_mp);
	backpack_slot = backpack_weight = 0;
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
	setName("anonymous");
}

OrcPlayer::OrcPlayer(int L)
{
	setExp(0);
	setMoney(100);
	weapon = NULL;
	armor = NULL;
	setLevel(L);
	setHp(max_hp);
	setMp(max_mp);
	backpack_slot = backpack_weight = 0;
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
	setName("anonymous");
}

OrcPlayer::OrcPlayer(int L, string N)
{
	setExp(0);
	setMoney(100);
	weapon = NULL;
	armor = NULL;
	setLevel(L);
	setHp(max_hp);
	setMp(max_mp);
	setName(N);
	backpack_slot = backpack_weight = 0;
	backpack = new Item*[backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = NULL;
}

OrcPlayer::OrcPlayer(const OrcPlayer& OP)
{
	if (OP.weapon == NULL)weapon = NULL;
	else weapon = OP.weapon;
	if (OP.armor == NULL)armor = NULL;
	else armor = OP.armor;
	setLevel(OP.getLevel());
	backpack = new Item*[OP.backpack_slot_limit + 3];
	for (int i = 0; i < backpack_slot_limit + 3; i++)
		backpack[i] = OP.backpack[i];
	setName(OP.getName());
	setHp(OP.getHp());
	setMp(OP.getMp());
	setExp(OP.getExp());
	setMoney(OP.getMoney());
	backpack_slot = OP.backpack_slot;
	backpack_weight = OP.backpack_weight;
}

void OrcPlayer::setLevel(int L)
{
	level = L;
	max_hp = 200 + 20 * L;
	max_mp = 50 + 5 * L;
	if (weapon == NULL)
		attack = 50 + 12 * L;
	else
		attack = 50 + 12 * L + weapon->attack_increment;
	if (armor == NULL)
		defense = 30 + 10 * L;
	else
		defense = 30 + 10 * L + armor->defense_increment;
	lvup_exp = ceil(pow(10, log2(L + 1)));
	backpack_weight_limit = 100 + 50 * L;
	backpack_slot_limit = 1 + L;
}

void OrcPlayer::specialSkill()
{
}

string OrcPlayer::serialize()
{
	stringstream ss;
	ss << "OrcPlayer" << "$";
	ss << getName() << "$";
	ss << getLevel() << "$";
	ss << getHp() << "$";
	ss << getMp() << "$";
	ss << getExp() << "$";
	ss << getMoney() << "$";
	ss << get_weapon() << "$";
	ss << get_armor() << "$";
	ss << get_backpack_slot() << "$";
	for (int i = 0; i < get_backpack_slot(); i++)
		ss << getItem(i)->name << "$";
	string s;
	s = ss.str();
	return s;
}
