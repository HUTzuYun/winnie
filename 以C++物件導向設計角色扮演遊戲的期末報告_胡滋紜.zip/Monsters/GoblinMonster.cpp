#include "GoblinMonster.h"
#include <sstream>
#include <iostream>
using namespace std;

BaseMonster* GoblinMonster::unserialize(string s)
{
	BaseMonster *BaseMonsterPtr = new GoblinMonster;
	stringstream ss(s);
	string temp;
	getline(ss, temp, '$');
	if (temp != "GoblinMonster")
		cout << "Warning: This string is not serialized as GoblinMonster." << endl;
	getline(ss, temp, '$');
	BaseMonsterPtr->setHP(stoi(temp));
	getline(ss, temp, '$');
	BaseMonsterPtr->setMP(stoi(temp));
	return BaseMonsterPtr;
}

GoblinMonster::GoblinMonster()
	:BaseMonster("GoblinMonster", 60, 40, 12, 30, 100, 50)
{
}

string GoblinMonster::serialize()
{
	stringstream ss;
	ss << name << "$" << getHP() << "$" << getMP() << "$";
	string s = ss.str();
	return s;
}

GoblinMonster::~GoblinMonster()
{
	--count;
}