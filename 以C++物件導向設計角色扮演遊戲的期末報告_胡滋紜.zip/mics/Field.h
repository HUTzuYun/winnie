#ifndef FIELD_H
#define FIELD_H

#include <string>
#include <vector>
using namespace std;

class Field
{
public:
    //(map_data, current_position_x, current_position_y, vision_width, vision_height, map_name, number of battles)
	Field(vector<vector<int>> , int, int, int, int, string, int);
	Field(const char*, int, int, int, int, string, int);
	bool move(char);
	bool moveUp();
	bool moveDown();
	bool moveLeft();
	bool moveRight();
	int getCurrentPositionX() const;
	int getCurrentPositionY() const;
	int getVisionWidth() const;
	int getVisionHeight() const;
	string getMapName() const;
	int getMapSymbol(int, int);                   //Parameter is the position (x,y)
	void setPosition(int, int);
	void setMapSymbol(int, int, int);
	void setVisionSize(int, int);
	void display() const;
	~Field();
private:
	int** map_data;
	int current_position_x;
	int current_position_y;
	string map_name;
	int vision_width;
	int vision_height;
	int row;
	int col;
};

#endif // !FIELD_H
