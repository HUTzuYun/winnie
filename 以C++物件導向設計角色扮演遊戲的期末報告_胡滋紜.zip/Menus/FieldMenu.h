#ifndef FIELDMENU_H
#define FIELDMENU_H

#include "Menu.h"
class Field;

class FieldMenu : public Menu
{
public:
	FieldMenu(Field&);
	virtual void display() const;
	char input();                 //return N(next step) or B(view backpack) or Q(quit)
	~FieldMenu();
private:
	Field *field;
};

#endif // !FIELDMENU_H

