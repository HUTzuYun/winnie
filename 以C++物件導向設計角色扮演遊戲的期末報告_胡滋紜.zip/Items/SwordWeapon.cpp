#include "SwordWeapon.h"

SwordWeapon::SwordWeapon()
	: WeaponItems(3, "Dragon-Sword", "Attack + 100", 
		"Long time ago, a hero used it to kill a evil dragon. Only lucky man can have it.", 80, 'w', 150, 100)
{
}

SwordWeapon::~SwordWeapon()
{
}