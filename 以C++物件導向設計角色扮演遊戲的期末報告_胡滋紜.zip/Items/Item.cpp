#include "Item.h"

Item::Item(
	const int levelRequired, const string &nameIn, const string &effect,
	const string &descriptionIn, const int weightIn, const char typeIn, const int costIn)
	:level_required(levelRequired), name(nameIn), effects(effect),
	description(descriptionIn), weight(weightIn), type(typeIn), cost(costIn)
{
}
