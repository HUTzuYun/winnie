#ifndef EVENT_H
#define EVENT_H

#include <vector>
using namespace std;

class NovicePlayer;

class Event
{
public:
	Event();
	virtual void display(vector<NovicePlayer*> &) = 0;
	virtual ~Event() {}
};

#endif // !EVENT_H

