#include "ShopEvent.h"
#include "NovicePlayer.h"
#include "AxeWeapon.h"
#include "SwordWeapon.h"
#include "ShieldArmor.h"
#include "TunicArmor.h"
#include "MagicPotion.h"
#include "LifePotion.h"
#include <iostream>
#include <iomanip>
using namespace std;

ShopEvent::ShopEvent()
{
	itemptr = new Item*[6];
	itemptr[0] = &axe;
	itemptr[1] = &sword;
	itemptr[2] = &shield;
	itemptr[3] = &tunic;
	itemptr[4] = &life_potion;
	itemptr[5] = &magic_potion;
}

void ShopEvent::display(vector<NovicePlayer*> &player_list)
{
	cout << "\nYou encounter a salesman...\n" << endl;
	system("pause");
	system("cls");
	cout << "\nSalesman: Hey, You are so lucky. I have some useful things on sale today. Here's the product list." << endl;
	cout << "\n--------------------------------------PRODUCTS' INFORMATIONS----------------------------------------" << endl;
	for (int i = 0; i < 6; i++)
		cout << "\n" << i + 1 << ". " << itemptr[i]->name <<
		"\n\nEffect: " << itemptr[i]->effects << "  Price: " << "$" << itemptr[i]->cost
		<< "  Level Requied: " << itemptr[i]->level_required <<
		"  Weight: " << itemptr[i]->weight
		<< "  Description: " << itemptr[i]->description << endl;
	cout << "\n------------------------------------------------------------------------------------------------------" << endl;
	cout << "You have $" << player_list[0]->getMoney() << endl;
	cout << "\nIs there anything you want to buy?" << endl;
	string yesOrNo;
	while (true)
	{
		cout << "\nEnter Y or N(Yes: Y || No: N):";
		getline(cin, yesOrNo);
		if (yesOrNo.size() == 1 && (yesOrNo == "Y" || yesOrNo == "N"))
			break;
	}
	if (yesOrNo == "Y") 
	{
		while (true)
		{
			int num;
			num = input();
			if (player_list[0]->getMoney() < itemptr[num - 1]->cost)
				cout << "\nSorry, you don't have enough money to buy " << itemptr[num - 1]->name << "." << endl;
			else if (player_list[0]->getLevel() < itemptr[num - 1]->level_required)
				cout << "\nSorry, your level is not high enough to buy " << itemptr[num - 1]->name << "." << endl;
			else 
			{
				bool buy;
				if (num == 1)
				{
					WeaponItems* ptr = &axe;
					buy = player_list[0]->equipWeapon(ptr);
				}
				else if (num == 2)
				{
					WeaponItems* ptr = &sword;
					buy = player_list[0]->equipWeapon(ptr);
				}
				else if (num == 3)
				{
					ArmorItems* ptr = &shield;
					buy = player_list[0]->equipArmor(ptr);
				}
				else if (num == 4)
				{
					ArmorItems* ptr = &tunic;
					buy = player_list[0]->equipArmor(ptr);
				}
				else
					buy = player_list[0]->putItem(itemptr[num - 1]);
				if (buy == true)
					player_list[0]->setMoney(player_list[0]->getMoney() - itemptr[num - 1]->cost);
				else
					cout << "\nExceed backpack solt limit (" << player_list[0]->get_backpack_slot_limit() <<
					") or backpack weight limit (" << player_list[0]->get_backpack_weight_limit() <<
					"). You cannot buy " << itemptr[num - 1]->name << "." << endl;
			}
			cout << "\nYou have $" << player_list[0]->getMoney() << endl;
			cout << "\nIs there anything else you want to buy?" << endl;
			string yesNo;
			while (true)
			{
				cout << "\nEnter Y or N(Yes: Y || No: N):";
				getline(cin, yesNo);
				if (yesNo.size() == 1 && (yesNo == "Y" || yesNo == "N"))
					break;
			}
			if (yesNo == "N") break;
		}
	}
	cout << endl;
	system("pause");
	system("cls");
}

int ShopEvent::input()
{
	string s;
	while (true)
	{
		cout << "\nEnter the product number that you want to buy ( 1 ~ 6 ):";
		getline(cin, s);
		if (s.size() != 1);
		else if (stoi(s) < 1 || stoi(s) > 6);
		else break;
	}
	return stoi(s);
}

ShopEvent::~ShopEvent()
{
	delete[] itemptr;
}