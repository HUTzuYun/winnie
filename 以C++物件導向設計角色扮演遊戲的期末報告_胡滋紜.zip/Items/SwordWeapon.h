#ifndef SWORDWEAPON_H
#define SWORDWEAPON_H

#include "WeaponItems.h"

class SwordWeapon : public WeaponItems
{
public:
	SwordWeapon();
	~SwordWeapon();
};

#endif // !SWORDWEAPON_H

