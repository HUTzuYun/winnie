#include "BaseMonster.h"

int BaseMonster::count = 0;

int BaseMonster::getInstanceCount()
{
	return count;
}

BaseMonster::BaseMonster(string s, int a, int d, int e, int m, int mh, int mm)
	:name(s), attack(a), defense(d), exp(e), money(m), max_hp(mh), max_mp(mm)
{
	hp = mp = 0;
	++count;
}

BaseMonster::~BaseMonster()
{
}

void BaseMonster::setHP(int h)
{
	if (h < 0) hp = 0;
	else if (h > max_hp) hp = max_hp;
	else hp = h;
}

int BaseMonster::getHP() const
{
	return hp;
}

void BaseMonster::setMP(int m)
{
	if (m < 0) mp = 0;
	else if (m > max_mp) mp = max_mp;
	else mp = m;
}

int BaseMonster::getMP() const
{
	return mp;
}

