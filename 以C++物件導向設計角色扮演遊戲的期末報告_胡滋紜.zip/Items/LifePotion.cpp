#include "LifePotion.h"

LifePotion::LifePotion()
	:ConsumableItems(2, "Life Juice", "Hp + 50", "It's very healthy and can save your life.", 30, 'c', 50)
{
}

LifePotion::~LifePotion()
{
}
